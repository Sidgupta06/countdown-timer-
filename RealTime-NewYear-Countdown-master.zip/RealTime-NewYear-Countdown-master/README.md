# RealTime-NewYear-Countdown

## New Year Countdown

- Landing page that counts down from the current date to the next new year

## Project Specifications

- Create landing page with HTML/CSS;<br>
- Calculate the days, hours, mins and seconds to the new year;<br>
- Insert values into the DOM;<br>
- Show a spinner right before loading the countdown;<br>
- Show the coming year in the background ;<br>

## Project Preview 

- Click Below Link <br><br>
[Click View Project](https://mian-ali.github.io/RealTime-NewYear-Countdown/) <br>

#### Project Broswer URL<br>
https://mian-ali.github.io/RealTime-NewYear-Countdown/


